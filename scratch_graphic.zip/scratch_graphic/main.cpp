#include <SDL2/SDL.h>
#include <bits/stdc++.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

using namespace std;

const float SLOT_SCALE = 0.75f;
const int SLOT_BLANK_W = 40;
const float CBLOCK_SCALE = 0.23f;
const int EMPTY_CBLOCK_HEIGHT = 40;

const int SCROLL_SPEED = 30;
const int SNAP_DISTANCE = 60;

const int AND_TEXT_W = 35; const int OR_TEXT_W = 25; const int NOT_TEXT_W = 30;
const int OP_PADDING = 10; const int OP_EDGE_PADDING = 15;

const int IF_TEXT_W_IF = 15; const int IF_TEXT_W_THEN = 35;
const int IF_PAD_LEFT = 20; const int IF_PAD_BETWEEN = 10; const int IF_PAD_RIGHT = 15;
const int IF_SLOT_Y_OFFSET = 5;
const int IF_TOP_LEFT_CAP = 45; const int IF_TOP_RIGHT_CAP = 15;

const int IFELSE_TEXT_W_ELSE = 30;
int ifelse_top_w = 0, ifelse_top_h = 0;
int ifelse_conn1_w = 0, ifelse_conn1_h = 0;
int ifelse_between_w = 0, ifelse_between_h = 0;
int ifelse_conn2_w = 0, ifelse_conn2_h = 0;
int ifelse_bott_w = 0, ifelse_bott_h = 0;
int ifelse_blank_w = 0, ifelse_blank_h = 0;

const int WAIT_TEXT_W = 60;
const int WAIT_PAD_LEFT = 15; const int WAIT_PAD_BETWEEN = 10; const int WAIT_PAD_RIGHT = 15;
const int WAIT_LEFT_CAP = 20; const int WAIT_RIGHT_CAP = 20;
int wait_bg_w = 0, wait_bg_h = 0;
int wait_blank_w = 0, wait_blank_h = 0;

const int REQ_TEXT_W = 75;
const int REQ_PAD_LEFT = 20; const int REQ_PAD_BETWEEN = 10; const int REQ_PAD_RIGHT = 15;
const int REQ_TOP_LEFT_CAP = 45; const int REQ_TOP_RIGHT_CAP = 15;
int req_top_w = 0, req_top_h = 0;
int req_conn_w = 0, req_conn_h = 0;
int req_bot_w = 0, req_bot_h = 0;
int req_blank_w = 0, req_blank_h = 0;

int rep_top_w = 0, rep_top_h = 0; int rep_conn_w = 0, rep_conn_h = 0; int rep_bot_w = 0, rep_bot_h = 0;
int forev_top_w = 0, forev_top_h = 0; int forev_conn_w = 0, forev_conn_h = 0; int forev_bot_w = 0, forev_bot_h = 0;

int if_top_w = 0, if_top_h = 0; int if_conn_w = 0, if_conn_h = 0;
int if_bot_w = 0, if_bot_h = 0; int if_blank_w = 0, if_blank_h = 0;

enum BlockCategory {
    CAT_MOTION, CAT_LOOKS, CAT_SOUND, CAT_EVENTS,
    CAT_CONTROL, CAT_SENSING, CAT_OPERATORS,
    CAT_VARIABLES, CAT_MY_BLOCK, CAT_PEN
};

enum BlockType {
    BLOCK_MOTION_MOVE_STEPS, BLOCK_MOTION_TURN_RIGHT, BLOCK_MOTION_TURN_LEFT,
    BLOCK_MOTION_GO_TO_XY, BLOCK_MOTION_CHANGR_X, BLOCK_MOTION_CHANGE_Y,
    BLOCK_MOTION_POINT_DIRECTION, BLOCK_MOTION_GO_TO,
    BLOCK_LOOKS_SAY, BLOCK_LOOKS_SAY_FOR_TIME, BLOCK_LOOKS_THINK,
    BLOCK_LOOKS_THINK_FOR_TIME, BLOCK_LOOKS_SWITCH_COSTUME, BLOCK_LOOKS_NEXT_COSTUME,
    BLOCK_LOOKS_SWITCH_BACKDROP, BLOCK_LOOKS_NEXT_BACKDROP, BLOCK_LOOKS_CHANGE_SIZE,
    BLOCK_LOOKS_SET_SIZE, BLOCK_LOOKS_CHANGE_EFFECT, BLOCK_LOOKS_SET_EFFECT,
    BLOCK_LOOKS_CLEAR_EFFECTS, BLOCK_LOOKS_SHOW, BLOCK_LOOKS_HIDE,
    BLOCK_LOOKS_GO_TO_FRONT_BACK, BLOCK_LOOKS_GO_FORWARD_BACKWARD,
    BLOCK_LOOKS_SIZE, BLOCK_LOOKS_COSTUME_NUMBER_NAME, BLOCK_LOOKS_BACKDROP_NUMBER_NAME,
    BLOCK_SOUND_PLAY, BLOCK_SOUND_PLAY_UNTIL_DONE, BLOCK_SOUND_STOP_ALL,
    BLOCK_SOUND_SET_VOLUME, BLOCK_SOUND_CHANGE_VOLUME, BLOCK_SOUND_CLEAR_EFFECTS,
    BLOCK_EVENT_FLAG_CLICKED, BLOCK_EVENT_KEY_PRESSED,
    BLOCK_EVENT_BROADCAST, BLOCK_EVENT_WHEN_RECIEVE,
    BLOCK_CONTROL_WAIT, BLOCK_CONTROL_REPEAT, BLOCK_CONTROL_FOREVER,
    BLOCK_CONTROL_IF, BLOCK_CONTROL_IF_ELSE, BLOCK_CONTROL_WAIT_UNTIL,
    REPEAT_UNTIL, BLOCK_CONTROL_STOP_ALL,
    BLOCK_SENSING_TOUCHING_OBJECT, BLOCK_SENSING_TOUCHING_COLOR,
    BLOCK_SENSING_COLOR_TOUCHING, BLOCK_SENSING_DISTANCE_TO,
    BLOCK_SENSING_ASK_AND_WAIT, BLOCK_SENSING_ANSWER, BLOCK_SENSING_KEY_PRESSED,
    BLOCK_SENSING_MOUSE_DOWN, BLOCK_SENSING_MOUSE_X, BLOCK_SENSING_MOUSE_Y,
    BLOCK_SENSING_SET_DRAG_MODE, BLOCK_SENSING_TIMER, BLOCK_SENSING_RESET_TIMER,
    BLOCK_OPERATOR_ADD, BLOCK_OPERATOR_SUBTRACT, BLOCK_OPERATOR_MULTIPLY,
    BLOCK_OPERATOR_DIVIDE, BLOCK_OPERATOR_GREATER_THAN, BLOCK_OPERATOR_LESS_THAN,
    BLOCK_OPERATOR_EQUAL, BLOCK_OPERATOR_AND, BLOCK_OPERATOR_OR, BLOCK_OPERATOR_NOT,
    BLOCK_OPERATOR_LENGTH_OF, BLOCK_OPERATOR_JOIN_STRING, BLOCK_OPERATOR_LETTER_OF,
    BLOCK_VARIABLE_SET, BLOCK_VARIABLE_CHANGE, BLOCK_VARIABLE_VALUE,
    BLOCK_COSTUME_DEFINE, BLOCK_COSTUME_CALL,
    BLOCK_PEN_ERASE_ALL, BLOCK_PEN_STAMP, BLOCK_PEN_DOWN, BLOCK_PEN_UP,
    BLOCK_PEN_SET_COLOR_RGB, BLOCK_PEN_SET_COLOR_ATTR,
    BLOCK_PEN_CHANGE_COLOR_ATTR, BLOCK_PEN_SET_SIZE, BLOCK_PEN_CHANGE_SIZE
};

struct TextInputBox {
    int relX, relY, w, h;
    string text;
    bool isFocused;
};

struct ColorInputBox {
    int relX, relY, w, h;
    SDL_Color color;
    bool isFocused;
};

struct CategoryButton {
    BlockCategory category; SDL_Texture* texture; SDL_Rect rect; bool isSelected;
};

struct MenuItem {
    BlockType type; BlockCategory category; SDL_Texture* texture; SDL_Rect rect;
    bool isHovered; bool hasDropdown; SDL_Rect dropdownRect; bool isDropdownOpen;
    vector<string> options; int selectedOptionIndex;
    vector<TextInputBox> inputFields;
    vector<ColorInputBox> colorFields;
};

const int MENU_AREA_X = 90; const int MENU_AREA_Y = 152; const int MENU_AREA_W = 310; const int MENU_AREA_H = 900;
const int DROP_AREA_X = 410; const int DROP_AREA_Y = 145; const int DROP_AREA_W = 900; const int DROP_AREA_H = 920;

TTF_Font* globalFont = nullptr;
SDL_Color colorWhite = {255, 255, 255, 255}; SDL_Color colorBlack = {0, 0, 0, 255};


vector<SDL_Color> colorPalette = {
        {255, 0, 0, 255}, {0, 255, 0, 255}, {0, 0, 255, 255},
        {255, 255, 0, 255}, {255, 165, 0, 255}, {128, 0, 128, 255},
        {255, 255, 255, 255}, {100, 100, 100, 255}, {0, 0, 0, 255}
};

SDL_Texture* tex_and_bg = nullptr;  SDL_Texture* tex_and_blank = nullptr;  SDL_Texture* tex_and_text = nullptr;
SDL_Texture* tex_or_bg = nullptr;   SDL_Texture* tex_or_blank = nullptr;   SDL_Texture* tex_or_text = nullptr;
SDL_Texture* tex_not_bg = nullptr;  SDL_Texture* tex_not_blank = nullptr;  SDL_Texture* tex_not_text = nullptr;
SDL_Texture* tex_rep_top = nullptr; SDL_Texture* tex_rep_conn = nullptr; SDL_Texture* tex_rep_bot = nullptr;
SDL_Texture* tex_forev_top = nullptr; SDL_Texture* tex_forev_conn = nullptr; SDL_Texture* tex_forev_bot = nullptr;
SDL_Texture* tex_if_top = nullptr; SDL_Texture* tex_if_conn = nullptr; SDL_Texture* tex_if_bot = nullptr; SDL_Texture* tex_if_blank = nullptr;
SDL_Texture* tex_ifelse_top = nullptr; SDL_Texture* tex_ifelse_conn1 = nullptr; SDL_Texture* tex_ifelse_between = nullptr;
SDL_Texture* tex_ifelse_conn2 = nullptr; SDL_Texture* tex_ifelse_bott = nullptr; SDL_Texture* tex_ifelse_blank = nullptr;
SDL_Texture* tex_wait_bg = nullptr; SDL_Texture* tex_wait_blank = nullptr;
SDL_Texture* tex_req_top = nullptr; SDL_Texture* tex_req_conn = nullptr; SDL_Texture* tex_req_bot = nullptr; SDL_Texture* tex_req_blank = nullptr;


struct DroppedBlock {
    BlockType type;
    SDL_Texture* texture;
    SDL_Rect rect;
    int originalW; int originalH; int dynamicTopW;
    DroppedBlock* next; DroppedBlock* inside; DroppedBlock* inside2;
    DroppedBlock* parent; DroppedBlock* arg1; DroppedBlock* arg2;

    bool hasDropdown;
    SDL_Rect dropdownRelativeRect;
    bool isDropdownOpen;
    vector<string> options;
    int selectedOptionIndex;

    vector<TextInputBox> inputFields;
    vector<ColorInputBox> colorFields;
};

DroppedBlock* activeDropdownBlock = nullptr;
MenuItem* activeMenuDropdown = nullptr;

TextInputBox* activeTextBox = nullptr;
int activeTextBoxAbsX = 0;
int activeTextBoxAbsY = 0;

ColorInputBox* activeColorBox = nullptr;
int activeColorBoxAbsX = 0;
int activeColorBoxAbsY = 0;

void renderText(SDL_Renderer* renderer, TTF_Font* font, const string& text, int x, int y, SDL_Color color, int wrapW = 0);
SDL_Texture* loadTex(const char* path, SDL_Renderer* renderer);
bool isMouseInside(int mouseX, int mouseY, SDL_Rect rect);
void setupMenu(SDL_Renderer* renderer, vector<CategoryButton>& catButtons, vector<MenuItem>& allBlocks);


void drawInputBoxes(SDL_Renderer* renderer, int bx, int by, const vector<TextInputBox>& boxes) {
    for (const auto& box : boxes) {
        if (box.isFocused && &box == activeTextBox) {
            activeTextBoxAbsX = bx + box.relX;
            activeTextBoxAbsY = by + box.relY;
            continue;
        }

        SDL_Rect absBox = {bx + box.relX, by + box.relY, box.w, box.h};
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderFillRect(renderer, &absBox);
        SDL_SetRenderDrawColor(renderer, 130, 130, 130, 255);
        SDL_RenderDrawRect(renderer, &absBox);

        if (!box.text.empty()) {
            SDL_Rect prevClip; SDL_RenderGetClipRect(renderer, &prevClip);
            bool hasPrevClip = !SDL_RectEmpty(&prevClip);
            SDL_Rect clipIntersect = absBox;
            if (hasPrevClip) SDL_IntersectRect(&absBox, &prevClip, &clipIntersect);
            SDL_RenderSetClipRect(renderer, &clipIntersect);
            renderText(renderer, globalFont, box.text, absBox.x + 3, absBox.y + 1, colorBlack, box.w - 4);
            if (hasPrevClip) SDL_RenderSetClipRect(renderer, &prevClip); else SDL_RenderSetClipRect(renderer, NULL);
        }
    }
}


void drawColorBoxes(SDL_Renderer* renderer, int bx, int by, const vector<ColorInputBox>& boxes) {
    for (const auto& box : boxes) {
        if (box.isFocused && &box == activeColorBox) {
            activeColorBoxAbsX = bx + box.relX;
            activeColorBoxAbsY = by + box.relY;
        }

        SDL_Rect absBox = {bx + box.relX, by + box.relY, box.w, box.h};


        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderFillRect(renderer, &absBox);


        SDL_Rect innerBox = {absBox.x + 2, absBox.y + 2, absBox.w - 4, absBox.h - 4};
        SDL_SetRenderDrawColor(renderer, box.color.r, box.color.g, box.color.b, box.color.a);
        SDL_RenderFillRect(renderer, &innerBox);
    }
}

bool isCBlock(BlockType type) { return (type == BLOCK_CONTROL_IF || type == BLOCK_CONTROL_IF_ELSE || type == BLOCK_CONTROL_REPEAT || type == BLOCK_CONTROL_FOREVER || type == REPEAT_UNTIL); }
bool isLogicalOp(BlockType type) { return (type == BLOCK_OPERATOR_AND || type == BLOCK_OPERATOR_OR || type == BLOCK_OPERATOR_NOT); }
DroppedBlock* getBottomBlock(DroppedBlock* node) { if (!node) return nullptr; while (node->next) node = node->next; return node; }
int getInnerBlocksHeight(DroppedBlock* head) { if (!head) return EMPTY_CBLOCK_HEIGHT; int h = 0; DroppedBlock* curr = head; while (curr) { h += curr->rect.h; curr = curr->next; } return h; }

void updateBlockPositions(DroppedBlock* block, int x, int y) {
    if (!block) return; block->rect.x = x; block->rect.y = y;
    if (isLogicalOp(block->type)) {
        int currentX = x + OP_EDGE_PADDING;
        int textW = (block->type == BLOCK_OPERATOR_AND) ? AND_TEXT_W : (block->type == BLOCK_OPERATOR_OR) ? OR_TEXT_W : NOT_TEXT_W;
        if (block->type == BLOCK_OPERATOR_NOT) {
            currentX += textW + OP_PADDING;
            if (block->arg1) { block->arg1->rect.w = block->arg1->originalW * SLOT_SCALE; block->arg1->rect.h = block->arg1->originalH * SLOT_SCALE; int arg1_y = y + (block->rect.h - block->arg1->rect.h) / 2; updateBlockPositions(block->arg1, currentX, arg1_y); currentX += block->arg1->rect.w; } else currentX += SLOT_BLANK_W;
        } else {
            if (block->arg1) { block->arg1->rect.w = block->arg1->originalW * SLOT_SCALE; block->arg1->rect.h = block->arg1->originalH * SLOT_SCALE; int arg1_y = y + (block->rect.h - block->arg1->rect.h) / 2; updateBlockPositions(block->arg1, currentX, arg1_y); currentX += block->arg1->rect.w; } else currentX += SLOT_BLANK_W;
            currentX += OP_PADDING + textW + OP_PADDING;
            if (block->arg2) { block->arg2->rect.w = block->arg2->originalW * SLOT_SCALE; block->arg2->rect.h = block->arg2->originalH * SLOT_SCALE; int arg2_y = y + (block->rect.h - block->arg2->rect.h) / 2; updateBlockPositions(block->arg2, currentX, arg2_y); currentX += block->arg2->rect.w; } else currentX += SLOT_BLANK_W;
        }
        currentX += OP_EDGE_PADDING; block->rect.w = currentX - x;
    }
    else if (block->type == BLOCK_CONTROL_IF) {
        int currentTopX = x + IF_PAD_LEFT + IF_TEXT_W_IF + IF_PAD_BETWEEN; int conditionW = if_blank_w;
        if (block->arg1) { block->arg1->rect.w = block->arg1->originalW * SLOT_SCALE; block->arg1->rect.h = block->arg1->originalH * SLOT_SCALE; updateBlockPositions(block->arg1, currentTopX, y + IF_SLOT_Y_OFFSET); conditionW = block->arg1->rect.w; }
        block->dynamicTopW = IF_PAD_LEFT + IF_TEXT_W_IF + IF_PAD_BETWEEN + conditionW + IF_PAD_BETWEEN + IF_TEXT_W_THEN + IF_PAD_RIGHT;
        if (block->dynamicTopW < if_top_w) block->dynamicTopW = if_top_w; block->rect.w = max(block->dynamicTopW, if_bot_w);
        if (block->inside) updateBlockPositions(block->inside, x + if_conn_w, y + if_top_h);
        block->rect.h = if_top_h + getInnerBlocksHeight(block->inside) + if_bot_h;
    }
    else if (block->type == BLOCK_CONTROL_IF_ELSE) {
        int currentTopX = x + IF_PAD_LEFT + IF_TEXT_W_IF + IF_PAD_BETWEEN; int conditionW = ifelse_blank_w;
        if (block->arg1) { block->arg1->rect.w = block->arg1->originalW * SLOT_SCALE; block->arg1->rect.h = block->arg1->originalH * SLOT_SCALE; updateBlockPositions(block->arg1, currentTopX, y + IF_SLOT_Y_OFFSET); conditionW = block->arg1->rect.w; }
        block->dynamicTopW = IF_PAD_LEFT + IF_TEXT_W_IF + IF_PAD_BETWEEN + conditionW + IF_PAD_BETWEEN + IF_TEXT_W_THEN + IF_PAD_RIGHT;
        if (block->dynamicTopW < ifelse_top_w) block->dynamicTopW = ifelse_top_w; block->rect.w = max({block->dynamicTopW, ifelse_bott_w, ifelse_between_w});
        int inner1_h = getInnerBlocksHeight(block->inside); if (block->inside) updateBlockPositions(block->inside, x + ifelse_conn1_w, y + ifelse_top_h);
        int betweenY = y + ifelse_top_h + inner1_h; int inner2_h = getInnerBlocksHeight(block->inside2);
        if (block->inside2) updateBlockPositions(block->inside2, x + ifelse_conn2_w, betweenY + ifelse_between_h);
        block->rect.h = ifelse_top_h + inner1_h + ifelse_between_h + inner2_h + ifelse_bott_h;
    }
    else if (block->type == REPEAT_UNTIL) {
        int currentTopX = x + REQ_PAD_LEFT + REQ_TEXT_W + REQ_PAD_BETWEEN; int conditionW = req_blank_w;
        if (block->arg1) { block->arg1->rect.w = block->arg1->originalW * SLOT_SCALE; block->arg1->rect.h = block->arg1->originalH * SLOT_SCALE; updateBlockPositions(block->arg1, currentTopX, y + IF_SLOT_Y_OFFSET); conditionW = block->arg1->rect.w; }
        block->dynamicTopW = REQ_PAD_LEFT + REQ_TEXT_W + REQ_PAD_BETWEEN + conditionW + REQ_PAD_BETWEEN + REQ_PAD_RIGHT;
        if (block->dynamicTopW < req_top_w) block->dynamicTopW = req_top_w; block->rect.w = max(block->dynamicTopW, req_bot_w);
        if (block->inside) updateBlockPositions(block->inside, x + req_conn_w, y + req_top_h); block->rect.h = req_top_h + getInnerBlocksHeight(block->inside) + req_bot_h;
    }
    else if (block->type == BLOCK_CONTROL_WAIT_UNTIL) {
        int currentX = x + WAIT_PAD_LEFT + WAIT_TEXT_W + WAIT_PAD_BETWEEN; int conditionW = wait_blank_w;
        if (block->arg1) { block->arg1->rect.w = block->arg1->originalW * SLOT_SCALE; block->arg1->rect.h = block->arg1->originalH * SLOT_SCALE; int arg1_y = y + (wait_bg_h - block->arg1->rect.h) / 2; updateBlockPositions(block->arg1, currentX, arg1_y); conditionW = block->arg1->rect.w; }
        int totalW = WAIT_PAD_LEFT + WAIT_TEXT_W + WAIT_PAD_BETWEEN + conditionW + WAIT_PAD_RIGHT; block->rect.w = max(totalW, wait_bg_w); block->rect.h = max(wait_bg_h, block->arg1 ? block->arg1->rect.h : 0);
    }
    else if (block->type == BLOCK_CONTROL_REPEAT) {
        if (block->inside) updateBlockPositions(block->inside, x + rep_conn_w, y + rep_top_h);
        block->rect.h = rep_top_h + getInnerBlocksHeight(block->inside) + rep_bot_h; block->rect.w = max(rep_top_w, rep_bot_w);
    }
    else if (block->type == BLOCK_CONTROL_FOREVER) {
        int currentTopX = x + 20 + 60 + 10;
        int conditionW = if_blank_w;
        if (block->arg1) { block->arg1->rect.w = block->arg1->originalW * SLOT_SCALE; block->arg1->rect.h = block->arg1->originalH * SLOT_SCALE; updateBlockPositions(block->arg1, currentTopX, y + IF_SLOT_Y_OFFSET); conditionW = block->arg1->rect.w; }
        block->dynamicTopW = 20 + 60 + 10 + conditionW + 15;
        if (block->dynamicTopW < forev_top_w) block->dynamicTopW = forev_top_w; block->rect.w = max(block->dynamicTopW, forev_bot_w);
        if (block->inside) updateBlockPositions(block->inside, x + forev_conn_w, y + forev_top_h);
        block->rect.h = forev_top_h + getInnerBlocksHeight(block->inside) + forev_bot_h;
    }
    else if (isCBlock(block->type) && block->inside) updateBlockPositions(block->inside, x + 15, y + 35);
    if (block->next) updateBlockPositions(block->next, x, block->rect.y + block->rect.h);
}

void renderBlockTree(SDL_Renderer* renderer, DroppedBlock* block) {
    if (!block) return;
    if (isLogicalOp(block->type)) {
        int h = block->rect.h; int cx = block->rect.x; int cy = block->rect.y;
        SDL_Texture* bgTex = (block->type == BLOCK_OPERATOR_AND) ? tex_and_bg : (block->type == BLOCK_OPERATOR_OR) ? tex_or_bg : tex_not_bg;
        SDL_Texture* blankTex = (block->type == BLOCK_OPERATOR_AND) ? tex_and_blank : (block->type == BLOCK_OPERATOR_OR) ? tex_or_blank : tex_not_blank;
        SDL_Texture* textTex = (block->type == BLOCK_OPERATOR_AND) ? tex_and_text : (block->type == BLOCK_OPERATOR_OR) ? tex_or_text : tex_not_text;
        int textW = (block->type == BLOCK_OPERATOR_AND) ? AND_TEXT_W : (block->type == BLOCK_OPERATOR_OR) ? OR_TEXT_W : NOT_TEXT_W;
        if (bgTex && blankTex && textTex) {
            int bgW, bgH; SDL_QueryTexture(bgTex, NULL, NULL, &bgW, &bgH); int capW = min(20, bgW / 3); int midDstW = max(1, block->rect.w - (2 * capW));
            SDL_Rect srcLeft = {0, 0, capW, bgH}; SDL_Rect dstLeft = {cx, cy, capW, h}; SDL_RenderCopy(renderer, bgTex, &srcLeft, &dstLeft);
            SDL_Rect srcMid = {capW, 0, bgW - 2*capW, bgH}; SDL_Rect dstMid = {cx + capW, cy, midDstW, h}; SDL_RenderCopy(renderer, bgTex, &srcMid, &dstMid);
            SDL_Rect srcRight = {bgW - capW, 0, capW, bgH}; SDL_Rect dstRight = {cx + capW + midDstW, cy, capW, h}; SDL_RenderCopy(renderer, bgTex, &srcRight, &dstRight);
            int innerX = cx + OP_EDGE_PADDING; int blankY = cy + (h - (h-8))/2;
            if (block->type == BLOCK_OPERATOR_NOT) {
                SDL_Rect rText = {innerX, blankY, textW, h - 8}; SDL_RenderCopy(renderer, textTex, NULL, &rText); innerX += textW + OP_PADDING;
                if (!block->arg1) { SDL_Rect r1 = {innerX, blankY, SLOT_BLANK_W, h - 8}; SDL_RenderCopy(renderer, blankTex, NULL, &r1); }
            } else {
                if (!block->arg1) { SDL_Rect r1 = {innerX, blankY, SLOT_BLANK_W, h - 8}; SDL_RenderCopy(renderer, blankTex, NULL, &r1); innerX += SLOT_BLANK_W; } else innerX += block->arg1->rect.w;
                innerX += OP_PADDING; SDL_Rect rText = {innerX, blankY, textW, h - 8}; SDL_RenderCopy(renderer, textTex, NULL, &rText); innerX += textW + OP_PADDING;
                if (!block->arg2) { SDL_Rect r2 = {innerX, blankY, SLOT_BLANK_W, h - 8}; SDL_RenderCopy(renderer, blankTex, NULL, &r2); }
            }
        }
    }
    else if (block->type == BLOCK_CONTROL_IF && tex_if_top) {
        int cx = block->rect.x; int cy = block->rect.y; int inner_h = getInnerBlocksHeight(block->inside); int top_total_w = block->dynamicTopW; int mid_w = top_total_w - IF_TOP_LEFT_CAP - IF_TOP_RIGHT_CAP; if(mid_w<1) mid_w=1;
        int texW, texH; SDL_QueryTexture(tex_if_top, NULL, NULL, &texW, &texH);
        SDL_Rect srcTopL = {0, 0, (int)(IF_TOP_LEFT_CAP / CBLOCK_SCALE), texH}; SDL_Rect dstTopL = {cx, cy, IF_TOP_LEFT_CAP, if_top_h}; SDL_RenderCopy(renderer, tex_if_top, &srcTopL, &dstTopL);
        SDL_Rect srcTopM = {(int)(IF_TOP_LEFT_CAP / CBLOCK_SCALE), 0, texW - (int)((IF_TOP_LEFT_CAP + IF_TOP_RIGHT_CAP)/CBLOCK_SCALE), texH}; SDL_Rect dstTopM = {cx + IF_TOP_LEFT_CAP, cy, mid_w, if_top_h}; SDL_RenderCopy(renderer, tex_if_top, &srcTopM, &dstTopM);
        SDL_Rect srcTopR = {texW - (int)(IF_TOP_RIGHT_CAP / CBLOCK_SCALE), 0, (int)(IF_TOP_RIGHT_CAP / CBLOCK_SCALE), texH}; SDL_Rect dstTopR = {cx + IF_TOP_LEFT_CAP + mid_w, cy, IF_TOP_RIGHT_CAP, if_top_h}; SDL_RenderCopy(renderer, tex_if_top, &srcTopR, &dstTopR);
        int textY = cy + (if_top_h / 2) - 8; int currentDrawX = cx + IF_PAD_LEFT; renderText(renderer, globalFont, "if", currentDrawX, textY, colorWhite); currentDrawX += IF_TEXT_W_IF + IF_PAD_BETWEEN;
        if (!block->arg1) { SDL_Rect rBlank = {currentDrawX, cy + IF_SLOT_Y_OFFSET, if_blank_w, if_blank_h}; SDL_RenderCopy(renderer, tex_if_blank, NULL, &rBlank); currentDrawX += if_blank_w; } else currentDrawX += block->arg1->rect.w;
        currentDrawX += IF_PAD_BETWEEN; renderText(renderer, globalFont, "then", currentDrawX, textY, colorWhite);
        SDL_Rect rConn = {cx, cy + if_top_h, if_conn_w, inner_h}; SDL_RenderCopy(renderer, tex_if_conn, NULL, &rConn); SDL_Rect rBot = {cx, cy + if_top_h + inner_h, if_bot_w, if_bot_h}; SDL_RenderCopy(renderer, tex_if_bot, NULL, &rBot);
    }
    else if (block->type == BLOCK_CONTROL_IF_ELSE && tex_ifelse_top) {
        int cx = block->rect.x; int cy = block->rect.y; int inner1_h = getInnerBlocksHeight(block->inside); int inner2_h = getInnerBlocksHeight(block->inside2);
        int top_total_w = block->dynamicTopW; int mid_w = top_total_w - IF_TOP_LEFT_CAP - IF_TOP_RIGHT_CAP; if(mid_w<1) mid_w=1; int texW, texH; SDL_QueryTexture(tex_ifelse_top, NULL, NULL, &texW, &texH);
        SDL_Rect srcTopL = {0, 0, (int)(IF_TOP_LEFT_CAP / CBLOCK_SCALE), texH}; SDL_Rect dstTopL = {cx, cy, IF_TOP_LEFT_CAP, ifelse_top_h}; SDL_RenderCopy(renderer, tex_ifelse_top, &srcTopL, &dstTopL);
        SDL_Rect srcTopM = {(int)(IF_TOP_LEFT_CAP / CBLOCK_SCALE), 0, texW - (int)((IF_TOP_LEFT_CAP + IF_TOP_RIGHT_CAP)/CBLOCK_SCALE), texH}; SDL_Rect dstTopM = {cx + IF_TOP_LEFT_CAP, cy, mid_w, ifelse_top_h}; SDL_RenderCopy(renderer, tex_ifelse_top, &srcTopM, &dstTopM);
        SDL_Rect srcTopR = {texW - (int)(IF_TOP_RIGHT_CAP / CBLOCK_SCALE), 0, (int)(IF_TOP_RIGHT_CAP / CBLOCK_SCALE), texH}; SDL_Rect dstTopR = {cx + IF_TOP_LEFT_CAP + mid_w, cy, IF_TOP_RIGHT_CAP, ifelse_top_h}; SDL_RenderCopy(renderer, tex_ifelse_top, &srcTopR, &dstTopR);
        int textY = cy + (ifelse_top_h / 2) - 8; int currentDrawX = cx + IF_PAD_LEFT; renderText(renderer, globalFont, "if", currentDrawX, textY, colorWhite); currentDrawX += IF_TEXT_W_IF + IF_PAD_BETWEEN;
        if (!block->arg1) { SDL_Rect rBlank = {currentDrawX, cy + IF_SLOT_Y_OFFSET, ifelse_blank_w, ifelse_blank_h}; SDL_RenderCopy(renderer, tex_ifelse_blank, NULL, &rBlank); currentDrawX += ifelse_blank_w; } else currentDrawX += block->arg1->rect.w;
        currentDrawX += IF_PAD_BETWEEN; renderText(renderer, globalFont, "then", currentDrawX, textY, colorWhite);
        SDL_Rect rConn1 = {cx, cy + ifelse_top_h, ifelse_conn1_w, inner1_h}; SDL_RenderCopy(renderer, tex_ifelse_conn1, NULL, &rConn1);
        int betweenY = cy + ifelse_top_h + inner1_h; SDL_Rect rBet = {cx, betweenY, ifelse_between_w, ifelse_between_h}; SDL_RenderCopy(renderer, tex_ifelse_between, NULL, &rBet);
        renderText(renderer, globalFont, "else", cx + IF_PAD_LEFT, betweenY + (ifelse_between_h / 2) - 8, colorWhite);
        SDL_Rect rConn2 = {cx, betweenY + ifelse_between_h, ifelse_conn2_w, inner2_h}; SDL_RenderCopy(renderer, tex_ifelse_conn2, NULL, &rConn2);
        SDL_Rect rBot = {cx, betweenY + ifelse_between_h + inner2_h, ifelse_bott_w, ifelse_bott_h}; SDL_RenderCopy(renderer, tex_ifelse_bott, NULL, &rBot);
    }
    else if (block->type == REPEAT_UNTIL && tex_req_top) {
        int cx = block->rect.x; int cy = block->rect.y; int inner_h = getInnerBlocksHeight(block->inside); int top_total_w = block->dynamicTopW; int mid_w = top_total_w - REQ_TOP_LEFT_CAP - REQ_TOP_RIGHT_CAP; if(mid_w<1) mid_w=1;
        int texW, texH; SDL_QueryTexture(tex_req_top, NULL, NULL, &texW, &texH);
        SDL_Rect srcTopL = {0, 0, (int)(REQ_TOP_LEFT_CAP / CBLOCK_SCALE), texH}; SDL_Rect dstTopL = {cx, cy, REQ_TOP_LEFT_CAP, req_top_h}; SDL_RenderCopy(renderer, tex_req_top, &srcTopL, &dstTopL);
        SDL_Rect srcTopM = {(int)(REQ_TOP_LEFT_CAP / CBLOCK_SCALE), 0, texW - (int)((REQ_TOP_LEFT_CAP + REQ_TOP_RIGHT_CAP)/CBLOCK_SCALE), texH}; SDL_Rect dstTopM = {cx + REQ_TOP_LEFT_CAP, cy, mid_w, req_top_h}; SDL_RenderCopy(renderer, tex_req_top, &srcTopM, &dstTopM);
        SDL_Rect srcTopR = {texW - (int)(REQ_TOP_RIGHT_CAP / CBLOCK_SCALE), 0, (int)(REQ_TOP_RIGHT_CAP / CBLOCK_SCALE), texH}; SDL_Rect dstTopR = {cx + REQ_TOP_LEFT_CAP + mid_w, cy, REQ_TOP_RIGHT_CAP, req_top_h}; SDL_RenderCopy(renderer, tex_req_top, &srcTopR, &dstTopR);
        int textY = cy + (req_top_h / 2) - 8; int currentDrawX = cx + REQ_PAD_LEFT; renderText(renderer, globalFont, "repeat until", currentDrawX, textY, colorWhite); currentDrawX += REQ_TEXT_W + REQ_PAD_BETWEEN;
        if (!block->arg1) { SDL_Rect rBlank = {currentDrawX, cy + IF_SLOT_Y_OFFSET, req_blank_w, req_blank_h}; SDL_RenderCopy(renderer, tex_req_blank, NULL, &rBlank); }
        SDL_Rect rConn = {cx, cy + req_top_h, req_conn_w, inner_h}; SDL_RenderCopy(renderer, tex_req_conn, NULL, &rConn);
        SDL_Rect rBot = {cx, cy + req_top_h + inner_h, req_bot_w, req_bot_h}; SDL_RenderCopy(renderer, tex_req_bot, NULL, &rBot);
    }
    else if (block->type == BLOCK_CONTROL_WAIT_UNTIL && tex_wait_bg) {
        int cx = block->rect.x; int cy = block->rect.y; int h = block->rect.h; int texW, texH; SDL_QueryTexture(tex_wait_bg, NULL, NULL, &texW, &texH); int mid_w = block->rect.w - WAIT_LEFT_CAP - WAIT_RIGHT_CAP; if(mid_w<1) mid_w=1;
        SDL_Rect srcL = {0, 0, (int)(WAIT_LEFT_CAP / CBLOCK_SCALE), texH}; SDL_Rect dstL = {cx, cy, WAIT_LEFT_CAP, h}; SDL_RenderCopy(renderer, tex_wait_bg, &srcL, &dstL);
        SDL_Rect srcM = {(int)(WAIT_LEFT_CAP / CBLOCK_SCALE), 0, texW - (int)((WAIT_LEFT_CAP+WAIT_RIGHT_CAP)/CBLOCK_SCALE), texH}; SDL_Rect dstM = {cx + WAIT_LEFT_CAP, cy, mid_w, h}; SDL_RenderCopy(renderer, tex_wait_bg, &srcM, &dstM);
        SDL_Rect srcR = {texW - (int)(WAIT_RIGHT_CAP / CBLOCK_SCALE), 0, (int)(WAIT_RIGHT_CAP / CBLOCK_SCALE), texH}; SDL_Rect dstR = {cx + WAIT_LEFT_CAP + mid_w, cy, WAIT_RIGHT_CAP, h}; SDL_RenderCopy(renderer, tex_wait_bg, &srcR, &dstR);
        int textY = cy + (h / 2) - 8; int currentDrawX = cx + WAIT_PAD_LEFT; renderText(renderer, globalFont, "wait until", currentDrawX, textY, colorWhite); currentDrawX += WAIT_TEXT_W + WAIT_PAD_BETWEEN;
        if (!block->arg1) { SDL_Rect rBlank = {currentDrawX, cy + (h - wait_blank_h)/2, wait_blank_w, wait_blank_h}; SDL_RenderCopy(renderer, tex_wait_blank, NULL, &rBlank); }
    }
    else if (block->type == BLOCK_CONTROL_REPEAT && tex_rep_top) {
        int cx = block->rect.x; int cy = block->rect.y; int inner_h = getInnerBlocksHeight(block->inside);
        SDL_Rect rTop = {cx, cy, rep_top_w, rep_top_h}; SDL_RenderCopy(renderer, tex_rep_top, NULL, &rTop);
        SDL_Rect rConn = {cx, cy + rep_top_h, rep_conn_w, inner_h}; SDL_RenderCopy(renderer, tex_rep_conn, NULL, &rConn);
        SDL_Rect rBot = {cx, cy + rep_top_h + inner_h, rep_bot_w, rep_bot_h}; SDL_RenderCopy(renderer, tex_rep_bot, NULL, &rBot);
    }
    else if (block->type == BLOCK_CONTROL_FOREVER && tex_forev_top) {
        int cx = block->rect.x; int cy = block->rect.y; int inner_h = getInnerBlocksHeight(block->inside); int top_total_w = block->dynamicTopW; int mid_w = top_total_w - IF_TOP_LEFT_CAP - IF_TOP_RIGHT_CAP; if(mid_w<1) mid_w=1;
        int texW, texH; SDL_QueryTexture(tex_forev_top, NULL, NULL, &texW, &texH);
        SDL_Rect srcTopL = {0, 0, (int)(IF_TOP_LEFT_CAP / CBLOCK_SCALE), texH}; SDL_Rect dstTopL = {cx, cy, IF_TOP_LEFT_CAP, forev_top_h}; SDL_RenderCopy(renderer, tex_forev_top, &srcTopL, &dstTopL);
        SDL_Rect srcTopM = {(int)(IF_TOP_LEFT_CAP / CBLOCK_SCALE), 0, texW - (int)((IF_TOP_LEFT_CAP + IF_TOP_RIGHT_CAP)/CBLOCK_SCALE), texH}; SDL_Rect dstTopM = {cx + IF_TOP_LEFT_CAP, cy, mid_w, forev_top_h}; SDL_RenderCopy(renderer, tex_forev_top, &srcTopM, &dstTopM);
        SDL_Rect srcTopR = {texW - (int)(IF_TOP_RIGHT_CAP / CBLOCK_SCALE), 0, (int)(IF_TOP_RIGHT_CAP / CBLOCK_SCALE), texH}; SDL_Rect dstTopR = {cx + IF_TOP_LEFT_CAP + mid_w, cy, IF_TOP_RIGHT_CAP, forev_top_h}; SDL_RenderCopy(renderer, tex_forev_top, &srcTopR, &dstTopR);
        int textY = cy + (forev_top_h / 2) - 8; int currentDrawX = cx + 20; renderText(renderer, globalFont, "forever", currentDrawX, textY, colorWhite); currentDrawX += 60 + 10;
        if (!block->arg1) { SDL_Rect rBlank = {currentDrawX, cy + IF_SLOT_Y_OFFSET, if_blank_w, if_blank_h}; SDL_RenderCopy(renderer, tex_if_blank, NULL, &rBlank); }
        SDL_Rect rConn = {cx, cy + forev_top_h, forev_conn_w, inner_h}; SDL_RenderCopy(renderer, tex_forev_conn, NULL, &rConn);
        SDL_Rect rBot = {cx, cy + forev_top_h + inner_h, forev_bot_w, forev_bot_h}; SDL_RenderCopy(renderer, tex_forev_bot, NULL, &rBot);
    }
    else {
        SDL_RenderCopy(renderer, block->texture, NULL, &block->rect);
    }

    if (block->hasDropdown && !block->options.empty()) {
        int dx = block->rect.x + block->dropdownRelativeRect.x; int dy = block->rect.y + block->dropdownRelativeRect.y;
        SDL_Rect boxRect = {dx, dy, block->dropdownRelativeRect.w, block->dropdownRelativeRect.h};
        SDL_SetRenderDrawColor(renderer, 245, 245, 245, 255); SDL_RenderFillRect(renderer, &boxRect);
        SDL_SetRenderDrawColor(renderer, 80, 80, 80, 255); SDL_RenderDrawRect(renderer, &boxRect);
        SDL_Rect arrowRect = {dx + block->dropdownRelativeRect.w - 12, dy + 10, 6, 5};
        SDL_SetRenderDrawColor(renderer, 100, 100, 100, 255); SDL_RenderFillRect(renderer, &arrowRect);
        renderText(renderer, globalFont, block->options[block->selectedOptionIndex], dx + 5, dy + 2, colorBlack);
    }

    drawInputBoxes(renderer, block->rect.x, block->rect.y, block->inputFields);
    drawColorBoxes(renderer, block->rect.x, block->rect.y, block->colorFields);

    if (block->arg1) renderBlockTree(renderer, block->arg1); if (block->arg2) renderBlockTree(renderer, block->arg2);
    if (block->inside) renderBlockTree(renderer, block->inside); if (block->inside2) renderBlockTree(renderer, block->inside2);
    if (block->next) renderBlockTree(renderer, block->next);
}

DroppedBlock* findClickedBlock(DroppedBlock* root, int mouseX, int mouseY) {
    if (!root) return nullptr;
    DroppedBlock* found = nullptr;
    if (root->next) found = findClickedBlock(root->next, mouseX, mouseY); if (found) return found;
    if (root->inside) found = findClickedBlock(root->inside, mouseX, mouseY); if (found) return found;
    if (root->inside2) found = findClickedBlock(root->inside2, mouseX, mouseY); if (found) return found;
    if (root->arg1) found = findClickedBlock(root->arg1, mouseX, mouseY); if (found) return found;
    if (root->arg2) found = findClickedBlock(root->arg2, mouseX, mouseY); if (found) return found;
    if (isMouseInside(mouseX, mouseY, root->rect)) return root;
    return nullptr;
}

void freeBlocks(DroppedBlock* block) {
    if (!block) return;
    if (block->inside) freeBlocks(block->inside); if (block->inside2) freeBlocks(block->inside2);
    if (block->next) freeBlocks(block->next);
    if (block->arg1) freeBlocks(block->arg1); if (block->arg2) freeBlocks(block->arg2);
    delete block;
}

void checkSnapping(DroppedBlock* root, DroppedBlock* dragged, DroppedBlock* draggedTail, DroppedBlock*& bestTarget, int& minDistance, int& bestSnapType) {
    if (!root || root == dragged) return;
    if (root->type != BLOCK_CONTROL_FOREVER) {
        int nextX = root->rect.x; int nextY = root->rect.y + root->rect.h; int distNext = abs(dragged->rect.x - nextX) + abs(dragged->rect.y - nextY);
        if (distNext < minDistance && distNext < SNAP_DISTANCE && !root->next) { minDistance = distNext; bestTarget = root; bestSnapType = 1; }
    }
    if (root->type == BLOCK_CONTROL_REPEAT || root->type == BLOCK_CONTROL_FOREVER) {
        int inX = root->rect.x + rep_conn_w; int inY = root->rect.y + rep_top_h; int distIn = abs(dragged->rect.x - inX) + abs(dragged->rect.y - inY);
        if (distIn < minDistance && distIn < SNAP_DISTANCE && !root->inside) { minDistance = distIn; bestTarget = root; bestSnapType = 2; }
    }
    if (root->type == BLOCK_CONTROL_FOREVER) {
        int arg1X = root->rect.x + 20 + 60 + 10; int distA1 = abs(dragged->rect.x - arg1X) + abs(dragged->rect.y - root->rect.y);
        if (distA1 < minDistance && distA1 < SNAP_DISTANCE && !root->arg1) { minDistance = distA1; bestTarget = root; bestSnapType = 4; }
    } else if (root->type == BLOCK_CONTROL_IF) {
        int arg1X = root->rect.x + IF_PAD_LEFT + IF_TEXT_W_IF + IF_PAD_BETWEEN; int distA1 = abs(dragged->rect.x - arg1X) + abs(dragged->rect.y - root->rect.y);
        if (distA1 < minDistance && distA1 < SNAP_DISTANCE && !root->arg1) { minDistance = distA1; bestTarget = root; bestSnapType = 4; }
        int inX = root->rect.x + if_conn_w; int inY = root->rect.y + if_top_h; int distIn = abs(dragged->rect.x - inX) + abs(dragged->rect.y - inY);
        if (distIn < minDistance && distIn < SNAP_DISTANCE && !root->inside) { minDistance = distIn; bestTarget = root; bestSnapType = 2; }
    } else if (root->type == BLOCK_CONTROL_IF_ELSE) {
        int arg1X = root->rect.x + IF_PAD_LEFT + IF_TEXT_W_IF + IF_PAD_BETWEEN; int distA1 = abs(dragged->rect.x - arg1X) + abs(dragged->rect.y - root->rect.y);
        if (distA1 < minDistance && distA1 < SNAP_DISTANCE && !root->arg1) { minDistance = distA1; bestTarget = root; bestSnapType = 4; }
        int in1X = root->rect.x + ifelse_conn1_w; int in1Y = root->rect.y + ifelse_top_h; int distIn1 = abs(dragged->rect.x - in1X) + abs(dragged->rect.y - in1Y);
        if (distIn1 < minDistance && distIn1 < SNAP_DISTANCE && !root->inside) { minDistance = distIn1; bestTarget = root; bestSnapType = 2; }
        int inner1_h = getInnerBlocksHeight(root->inside); int in2X = root->rect.x + ifelse_conn2_w; int in2Y = root->rect.y + ifelse_top_h + inner1_h + ifelse_between_h; int distIn2 = abs(dragged->rect.x - in2X) + abs(dragged->rect.y - in2Y);
        if (distIn2 < minDistance && distIn2 < SNAP_DISTANCE && !root->inside2) { minDistance = distIn2; bestTarget = root; bestSnapType = 6; }
    } else if (root->type == REPEAT_UNTIL) {
        int arg1X = root->rect.x + REQ_PAD_LEFT + REQ_TEXT_W + REQ_PAD_BETWEEN; int distA1 = abs(dragged->rect.x - arg1X) + abs(dragged->rect.y - root->rect.y);
        if (distA1 < minDistance && distA1 < SNAP_DISTANCE && !root->arg1) { minDistance = distA1; bestTarget = root; bestSnapType = 4; }
        int inX = root->rect.x + req_conn_w; int inY = root->rect.y + req_top_h; int distIn = abs(dragged->rect.x - inX) + abs(dragged->rect.y - inY);
        if (distIn < minDistance && distIn < SNAP_DISTANCE && !root->inside) { minDistance = distIn; bestTarget = root; bestSnapType = 2; }
    } else if (root->type == BLOCK_CONTROL_WAIT_UNTIL) {
        int arg1X = root->rect.x + WAIT_PAD_LEFT + WAIT_TEXT_W + WAIT_PAD_BETWEEN; int distA1 = abs(dragged->rect.x - arg1X) + abs(dragged->rect.y - root->rect.y);
        if (distA1 < minDistance && distA1 < SNAP_DISTANCE && !root->arg1) { minDistance = distA1; bestTarget = root; bestSnapType = 4; }
    }
    if (!root->parent) {
        int tailBottomX = draggedTail->rect.x; int tailBottomY = draggedTail->rect.y + draggedTail->rect.h; int distTop = abs(tailBottomX - root->rect.x) + abs(tailBottomY - root->rect.y);
        if (distTop < minDistance && distTop < SNAP_DISTANCE) { minDistance = distTop; bestTarget = root; bestSnapType = 3; }
    }
    if (isLogicalOp(root->type)) {
        if (root->type == BLOCK_OPERATOR_NOT) {
            int arg1X = root->rect.x + OP_EDGE_PADDING + NOT_TEXT_W + OP_PADDING; int distA1 = abs(dragged->rect.x - arg1X) + abs(dragged->rect.y - root->rect.y);
            if (distA1 < minDistance && distA1 < SNAP_DISTANCE && !root->arg1) { minDistance = distA1; bestTarget = root; bestSnapType = 4; }
        } else {
            int arg1X = root->rect.x + OP_EDGE_PADDING; int distA1 = abs(dragged->rect.x - arg1X) + abs(dragged->rect.y - root->rect.y);
            if (distA1 < minDistance && distA1 < SNAP_DISTANCE && !root->arg1) { minDistance = distA1; bestTarget = root; bestSnapType = 4; }
            int w_left = root->arg1 ? root->arg1->rect.w : SLOT_BLANK_W; int textW = (root->type == BLOCK_OPERATOR_AND) ? AND_TEXT_W : OR_TEXT_W;
            int arg2X = root->rect.x + OP_EDGE_PADDING + w_left + OP_PADDING + textW + OP_PADDING; int distA2 = abs(dragged->rect.x - arg2X) + abs(dragged->rect.y - root->rect.y);
            if (distA2 < minDistance && distA2 < SNAP_DISTANCE && !root->arg2) { minDistance = distA2; bestTarget = root; bestSnapType = 5; }
        }
    }
    if (root->inside) checkSnapping(root->inside, dragged, draggedTail, bestTarget, minDistance, bestSnapType);
    if (root->inside2) checkSnapping(root->inside2, dragged, draggedTail, bestTarget, minDistance, bestSnapType);
    if (root->next) checkSnapping(root->next, dragged, draggedTail, bestTarget, minDistance, bestSnapType);
    if (root->arg1) checkSnapping(root->arg1, dragged, draggedTail, bestTarget, minDistance, bestSnapType);
    if (root->arg2) checkSnapping(root->arg2, dragged, draggedTail, bestTarget, minDistance, bestSnapType);
}

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO); IMG_Init(IMG_INIT_PNG); TTF_Init();
    SDL_Window* window = SDL_CreateWindow("Scratch Clone", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1920, 1080, SDL_WINDOW_FULLSCREEN_DESKTOP);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND); SDL_RenderSetLogicalSize(renderer, 1920, 1080);

    globalFont = TTF_OpenFont("ARIAL.ttf", 15);

    SDL_Texture* background = loadTex("background_notComplete_2.png", renderer);
    tex_and_bg = loadTex("and_bg.png", renderer); tex_and_blank = loadTex("and_blank.png", renderer); tex_and_text = loadTex("and_text.png", renderer);
    tex_or_bg = loadTex("or_bg.png", renderer); tex_or_blank = loadTex("or_blank.png", renderer); tex_or_text = loadTex("or_text.png", renderer);
    tex_not_bg = loadTex("not_bg.png", renderer); tex_not_blank = loadTex("not_blank.png", renderer); tex_not_text = loadTex("not_text.png", renderer);
    tex_rep_top = loadTex("repeat_top.png", renderer); tex_rep_conn = loadTex("repeat_conn.png", renderer); tex_rep_bot = loadTex("repeat_bottom.png", renderer);
    tex_forev_top = loadTex("forever_top.png", renderer); tex_forev_conn = loadTex("forever_conn.png", renderer); tex_forev_bot = loadTex("forever_bott.png", renderer);
    tex_if_top = loadTex("if_top.png", renderer); tex_if_conn = loadTex("if_conn.png", renderer); tex_if_bot = loadTex("if_bott.png", renderer); tex_if_blank = loadTex("if_blank.png", renderer);
    tex_ifelse_top = loadTex("ifelse_top.png", renderer); tex_ifelse_conn1 = loadTex("ifelse_conn1.png", renderer);
    tex_ifelse_between = loadTex("ifelse_between.png", renderer); tex_ifelse_conn2 = loadTex("ifelse_conn2.png", renderer);
    tex_ifelse_bott = loadTex("ifelse_bott.png", renderer); tex_ifelse_blank = loadTex("ifelse_blank.png", renderer);
    tex_wait_bg = loadTex("wait_bg.png", renderer); tex_wait_blank = loadTex("wait_blank.png", renderer);
    tex_req_top = loadTex("requni_top.png", renderer); tex_req_conn = loadTex("requni_conn.png", renderer);
    tex_req_bot = loadTex("requni_bott.png", renderer); tex_req_blank = loadTex("requni_blank.png", renderer);

    int orig_w, orig_h;
    if (tex_rep_top) { SDL_QueryTexture(tex_rep_top, NULL, NULL, &orig_w, &orig_h); rep_top_w = orig_w * CBLOCK_SCALE; rep_top_h = orig_h * CBLOCK_SCALE; }
    if (tex_rep_conn) { SDL_QueryTexture(tex_rep_conn, NULL, NULL, &orig_w, &orig_h); rep_conn_w = orig_w * CBLOCK_SCALE; rep_conn_h = orig_h * CBLOCK_SCALE; }
    if (tex_rep_bot) { SDL_QueryTexture(tex_rep_bot, NULL, NULL, &orig_w, &orig_h); rep_bot_w = orig_w * CBLOCK_SCALE; rep_bot_h = orig_h * CBLOCK_SCALE; }
    if (tex_forev_top) { SDL_QueryTexture(tex_forev_top, NULL, NULL, &orig_w, &orig_h); forev_top_w = orig_w * CBLOCK_SCALE; forev_top_h = orig_h * CBLOCK_SCALE; }
    if (tex_forev_conn) { SDL_QueryTexture(tex_forev_conn, NULL, NULL, &orig_w, &orig_h); forev_conn_w = orig_w * CBLOCK_SCALE; forev_conn_h = orig_h * CBLOCK_SCALE; }
    if (tex_forev_bot) { SDL_QueryTexture(tex_forev_bot, NULL, NULL, &orig_w, &orig_h); forev_bot_w = orig_w * CBLOCK_SCALE; forev_bot_h = orig_h * CBLOCK_SCALE; }
    if (tex_if_top) { SDL_QueryTexture(tex_if_top, NULL, NULL, &orig_w, &orig_h); if_top_w = orig_w * CBLOCK_SCALE; if_top_h = orig_h * CBLOCK_SCALE; }
    if (tex_if_conn) { SDL_QueryTexture(tex_if_conn, NULL, NULL, &orig_w, &orig_h); if_conn_w = orig_w * CBLOCK_SCALE; if_conn_h = orig_h * CBLOCK_SCALE; }
    if (tex_if_bot) { SDL_QueryTexture(tex_if_bot, NULL, NULL, &orig_w, &orig_h); if_bot_w = orig_w * CBLOCK_SCALE; if_bot_h = orig_h * CBLOCK_SCALE; }
    if (tex_if_blank) { SDL_QueryTexture(tex_if_blank, NULL, NULL, &orig_w, &orig_h); if_blank_w = orig_w * CBLOCK_SCALE; if_blank_h = orig_h * CBLOCK_SCALE; }
    if (tex_ifelse_top) { SDL_QueryTexture(tex_ifelse_top, NULL, NULL, &orig_w, &orig_h); ifelse_top_w = orig_w * CBLOCK_SCALE; ifelse_top_h = orig_h * CBLOCK_SCALE; }
    if (tex_ifelse_conn1) { SDL_QueryTexture(tex_ifelse_conn1, NULL, NULL, &orig_w, &orig_h); ifelse_conn1_w = orig_w * CBLOCK_SCALE; ifelse_conn1_h = orig_h * CBLOCK_SCALE; }
    if (tex_ifelse_between) { SDL_QueryTexture(tex_ifelse_between, NULL, NULL, &orig_w, &orig_h); ifelse_between_w = orig_w * CBLOCK_SCALE; ifelse_between_h = orig_h * CBLOCK_SCALE; }
    if (tex_ifelse_conn2) { SDL_QueryTexture(tex_ifelse_conn2, NULL, NULL, &orig_w, &orig_h); ifelse_conn2_w = orig_w * CBLOCK_SCALE; ifelse_conn2_h = orig_h * CBLOCK_SCALE; }
    if (tex_ifelse_bott) { SDL_QueryTexture(tex_ifelse_bott, NULL, NULL, &orig_w, &orig_h); ifelse_bott_w = orig_w * CBLOCK_SCALE; ifelse_bott_h = orig_h * CBLOCK_SCALE; }
    if (tex_ifelse_blank) { SDL_QueryTexture(tex_ifelse_blank, NULL, NULL, &orig_w, &orig_h); ifelse_blank_w = orig_w * CBLOCK_SCALE; ifelse_blank_h = orig_h * CBLOCK_SCALE; }
    if (tex_wait_bg) { SDL_QueryTexture(tex_wait_bg, NULL, NULL, &orig_w, &orig_h); wait_bg_w = orig_w * CBLOCK_SCALE; wait_bg_h = orig_h * CBLOCK_SCALE; }
    if (tex_wait_blank) { SDL_QueryTexture(tex_wait_blank, NULL, NULL, &orig_w, &orig_h); wait_blank_w = orig_w * CBLOCK_SCALE; wait_blank_h = orig_h * CBLOCK_SCALE; }
    if (tex_req_top) { SDL_QueryTexture(tex_req_top, NULL, NULL, &orig_w, &orig_h); req_top_w = orig_w * CBLOCK_SCALE; req_top_h = orig_h * CBLOCK_SCALE; }
    if (tex_req_conn) { SDL_QueryTexture(tex_req_conn, NULL, NULL, &orig_w, &orig_h); req_conn_w = orig_w * CBLOCK_SCALE; req_conn_h = orig_h * CBLOCK_SCALE; }
    if (tex_req_bot) { SDL_QueryTexture(tex_req_bot, NULL, NULL, &orig_w, &orig_h); req_bot_w = orig_w * CBLOCK_SCALE; req_bot_h = orig_h * CBLOCK_SCALE; }
    if (tex_req_blank) { SDL_QueryTexture(tex_req_blank, NULL, NULL, &orig_w, &orig_h); req_blank_w = orig_w * CBLOCK_SCALE; req_blank_h = orig_h * CBLOCK_SCALE; }

    vector<CategoryButton> catButtons; vector<MenuItem> menuBlocks; setupMenu(renderer, catButtons, menuBlocks);

    BlockCategory activeCategory = CAT_MOTION; bool running = true; SDL_Event e; map<BlockCategory, int> scrollOffsets;
    DroppedBlock* draggedBlock = nullptr; int dragOffsetX = 0, dragOffsetY = 0; vector<DroppedBlock*> topLevelBlocks;

    while (running) {
        int mouseX, mouseY; SDL_GetMouseState(&mouseX, &mouseY); int& scrollY = scrollOffsets[activeCategory];

        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT || (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE)) running = false;
            if (e.type == SDL_MOUSEWHEEL) { SDL_Rect menuArea = {MENU_AREA_X, MENU_AREA_Y, MENU_AREA_W, MENU_AREA_H}; if(isMouseInside(mouseX,mouseY,menuArea)) { scrollY -= e.wheel.y*SCROLL_SPEED; if(scrollY<0)scrollY=0; } }

            if (e.type == SDL_TEXTINPUT && activeTextBox) activeTextBox->text += e.text.text;
            else if (e.type == SDL_KEYDOWN && activeTextBox) {
                if (e.key.keysym.sym == SDLK_BACKSPACE && activeTextBox->text.length() > 0) {
                    while(!activeTextBox->text.empty()) { char c = activeTextBox->text.back(); activeTextBox->text.pop_back(); if((c & 0xC0) != 0x80) break; }
                }
                else if (e.key.keysym.sym == SDLK_RETURN || e.key.keysym.sym == SDLK_KP_ENTER) {
                    activeTextBox->isFocused = false; activeTextBox = nullptr; SDL_StopTextInput();
                }
            }

            if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
                bool clickedOnInput = false;


                if (activeColorBox) {
                    int palX = activeColorBoxAbsX; int palY = activeColorBoxAbsY + activeColorBox->h + 5;
                    SDL_Rect palRect = {palX - 2, palY - 2, 85, 85}; // 3x3 grid, each 25x25 + spacing
                    if (isMouseInside(mouseX, mouseY, palRect)) {
                        int col = (mouseX - palX) / 28; int row = (mouseY - palY) / 28;
                        int index = row * 3 + col;
                        if (index >= 0 && index < colorPalette.size()) {
                            activeColorBox->color = colorPalette[index];
                        }
                        clickedOnInput = true;
                    }
                    activeColorBox->isFocused = false;
                    activeColorBox = nullptr;
                    if(clickedOnInput) continue;
                }

                if (activeDropdownBlock || activeMenuDropdown) {
                    int optH = 25; vector<string>* options = nullptr; int bx, by; int* selectedIndexPtr = nullptr;
                    if (activeDropdownBlock) { options = &activeDropdownBlock->options; bx = activeDropdownBlock->rect.x + activeDropdownBlock->dropdownRelativeRect.x; by = activeDropdownBlock->rect.y + activeDropdownBlock->dropdownRelativeRect.y + activeDropdownBlock->dropdownRelativeRect.h; selectedIndexPtr = &activeDropdownBlock->selectedOptionIndex; }
                    else { options = &activeMenuDropdown->options; int blockRenderY = activeMenuDropdown->rect.y - scrollY; bx = activeMenuDropdown->rect.x + activeMenuDropdown->dropdownRect.x; by = blockRenderY + activeMenuDropdown->dropdownRect.y + activeMenuDropdown->dropdownRect.h; selectedIndexPtr = &activeMenuDropdown->selectedOptionIndex; }
                    int w = 150; for(string s : *options) { if(s.length() > 10) w = 220; } int totalH = optH * options->size(); SDL_Rect listRect = {bx, by, w, totalH};
                    if (isMouseInside(mouseX, mouseY, listRect)) { int index = (mouseY - by) / optH; if (index >= 0 && index < options->size()) *selectedIndexPtr = index; }
                    if (activeDropdownBlock) activeDropdownBlock->isDropdownOpen = false; activeDropdownBlock = nullptr; activeMenuDropdown = nullptr;
                    continue;
                }

                for (const auto& btn : catButtons) { if (isMouseInside(mouseX, mouseY, btn.rect)) { activeCategory = btn.category; break; } }
                for (auto& btn : catButtons) btn.isSelected = (btn.category == activeCategory);

                SDL_Rect dropArea = {DROP_AREA_X, DROP_AREA_Y, DROP_AREA_W, DROP_AREA_H};
                if (isMouseInside(mouseX, mouseY, dropArea)) {
                    for (int i = (int)topLevelBlocks.size() - 1; i >= 0; i--) {
                        DroppedBlock* clicked = findClickedBlock(topLevelBlocks[i], mouseX, mouseY);
                        if (clicked) {
                            if (clicked->hasDropdown) {
                                SDL_Rect absDrop = { clicked->rect.x + clicked->dropdownRelativeRect.x, clicked->rect.y + clicked->dropdownRelativeRect.y, clicked->dropdownRelativeRect.w, clicked->dropdownRelativeRect.h };
                                if (isMouseInside(mouseX, mouseY, absDrop)) { activeDropdownBlock = clicked; clicked->isDropdownOpen = true; clickedOnInput = true; break; }
                            }

                            for(auto& box : clicked->inputFields) {
                                int hBox = box.isFocused ? box.h * 3 : box.h;
                                SDL_Rect absBox = { clicked->rect.x + box.relX, clicked->rect.y + box.relY, box.w, hBox };
                                if (isMouseInside(mouseX, mouseY, absBox)) {
                                    if(activeTextBox) activeTextBox->isFocused = false;
                                    activeTextBox = &box; activeTextBox->isFocused = true; clickedOnInput = true; SDL_StartTextInput(); break;
                                }
                            }
                            if(clickedOnInput) break;


                            for(auto& box : clicked->colorFields) {
                                SDL_Rect absBox = { clicked->rect.x + box.relX, clicked->rect.y + box.relY, box.w, box.h };
                                if (isMouseInside(mouseX, mouseY, absBox)) {
                                    activeColorBox = &box; activeColorBox->isFocused = true; clickedOnInput = true; break;
                                }
                            }
                            if(clickedOnInput) break;

                            if(!activeDropdownBlock && !activeMenuDropdown) {
                                draggedBlock = clicked; dragOffsetX = mouseX - clicked->rect.x; dragOffsetY = mouseY - clicked->rect.y;
                                if (clicked->parent) {
                                    if (clicked->parent->next == clicked) clicked->parent->next = nullptr;
                                    else if (clicked->parent->inside == clicked) clicked->parent->inside = nullptr;
                                    else if (clicked->parent->inside2 == clicked) clicked->parent->inside2 = nullptr;
                                    else if (clicked->parent->arg1 == clicked) clicked->parent->arg1 = nullptr;
                                    else if (clicked->parent->arg2 == clicked) clicked->parent->arg2 = nullptr;
                                    clicked->rect.w = clicked->originalW; clicked->rect.h = clicked->originalH;
                                    updateBlockPositions(clicked->parent, clicked->parent->rect.x, clicked->parent->rect.y);
                                    clicked->parent = nullptr; topLevelBlocks.push_back(clicked);
                                }
                                auto it = find(topLevelBlocks.begin(), topLevelBlocks.end(), draggedBlock);
                                if (it != topLevelBlocks.end()) { topLevelBlocks.erase(it); topLevelBlocks.push_back(draggedBlock); }
                            }
                            break;
                        }
                    }
                }

                if (!draggedBlock && !activeDropdownBlock && !activeMenuDropdown && !clickedOnInput) {
                    for (auto& block : menuBlocks) {
                        if (block.category != activeCategory) continue;
                        SDL_Rect renderedRect = {block.rect.x, block.rect.y - scrollY, block.rect.w, block.rect.h};
                        if (renderedRect.y + renderedRect.h <= MENU_AREA_Y || renderedRect.y >= MENU_AREA_Y + MENU_AREA_H) continue;

                        if (isMouseInside(mouseX, mouseY, renderedRect)) {
                            if (block.hasDropdown) {
                                SDL_Rect absDrop = { renderedRect.x + block.dropdownRect.x, renderedRect.y + block.dropdownRect.y, block.dropdownRect.w, block.dropdownRect.h };
                                if (isMouseInside(mouseX, mouseY, absDrop)) { activeMenuDropdown = &block; break; }
                            }

                            for(auto& box : block.inputFields) {
                                int hBox = box.isFocused ? box.h * 3 : box.h;
                                SDL_Rect absBox = { renderedRect.x + box.relX, renderedRect.y + box.relY, box.w, hBox };
                                if (isMouseInside(mouseX, mouseY, absBox)) {
                                    if(activeTextBox) activeTextBox->isFocused = false;
                                    activeTextBox = &box; activeTextBox->isFocused = true; clickedOnInput = true; SDL_StartTextInput(); break;
                                }
                            }
                            if(clickedOnInput) break;


                            for(auto& box : block.colorFields) {
                                SDL_Rect absBox = { renderedRect.x + box.relX, renderedRect.y + box.relY, box.w, box.h };
                                if (isMouseInside(mouseX, mouseY, absBox)) {
                                    activeColorBox = &box; activeColorBox->isFocused = true; clickedOnInput = true; break;
                                }
                            }
                            if(clickedOnInput) break;

                            int initW = renderedRect.w; int initH = renderedRect.h; int topW = 0;
                            if (block.type == BLOCK_CONTROL_REPEAT) { initW = max(rep_top_w, rep_bot_w); initH = rep_top_h + EMPTY_CBLOCK_HEIGHT + rep_bot_h; }
                            else if (block.type == BLOCK_CONTROL_FOREVER) { initW = max(forev_top_w, forev_bot_w); initH = forev_top_h + EMPTY_CBLOCK_HEIGHT + forev_bot_h; }
                            else if (block.type == BLOCK_CONTROL_IF) {
                                topW = IF_PAD_LEFT + IF_TEXT_W_IF + IF_PAD_BETWEEN + if_blank_w + IF_PAD_BETWEEN + IF_TEXT_W_THEN + IF_PAD_RIGHT;
                                initW = max(topW, if_bot_w); initH = if_top_h + EMPTY_CBLOCK_HEIGHT + if_bot_h;
                            }
                            else if (block.type == BLOCK_CONTROL_IF_ELSE) {
                                topW = IF_PAD_LEFT + IF_TEXT_W_IF + IF_PAD_BETWEEN + ifelse_blank_w + IF_PAD_BETWEEN + IF_TEXT_W_THEN + IF_PAD_RIGHT;
                                initW = max({topW, ifelse_bott_w, ifelse_between_w}); initH = ifelse_top_h + EMPTY_CBLOCK_HEIGHT + ifelse_between_h + EMPTY_CBLOCK_HEIGHT + ifelse_bott_h;
                            }
                            else if (block.type == BLOCK_CONTROL_WAIT_UNTIL) {
                                initW = max(WAIT_PAD_LEFT + WAIT_TEXT_W + WAIT_PAD_BETWEEN + wait_blank_w + WAIT_PAD_RIGHT, wait_bg_w); initH = wait_bg_h;
                            }
                            else if (block.type == REPEAT_UNTIL) {
                                topW = REQ_PAD_LEFT + REQ_TEXT_W + REQ_PAD_BETWEEN + req_blank_w + REQ_PAD_RIGHT; initW = max(topW, req_bot_w); initH = req_top_h + EMPTY_CBLOCK_HEIGHT + req_bot_h;
                            }

                            draggedBlock = new DroppedBlock{
                                    block.type, block.texture, {renderedRect.x, renderedRect.y, initW, initH},
                                    initW, initH, topW, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
                                    block.hasDropdown, block.dropdownRect, false, block.options, block.selectedOptionIndex,
                                    block.inputFields, block.colorFields
                            };
                            dragOffsetX = mouseX - renderedRect.x; dragOffsetY = mouseY - renderedRect.y;
                            topLevelBlocks.push_back(draggedBlock); break;
                        }
                    }
                }

                if (!clickedOnInput && activeTextBox) {
                    activeTextBox->isFocused = false; activeTextBox = nullptr; SDL_StopTextInput();
                }
            }

            if (e.type == SDL_MOUSEMOTION && draggedBlock) updateBlockPositions(draggedBlock, mouseX - dragOffsetX, mouseY - dragOffsetY);

            if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) {
                if (draggedBlock) {
                    SDL_Rect dropArea = {DROP_AREA_X, DROP_AREA_Y, DROP_AREA_W, DROP_AREA_H};
                    if (!isMouseInside(mouseX, mouseY, dropArea)) {
                        auto it = find(topLevelBlocks.begin(), topLevelBlocks.end(), draggedBlock);
                        if (it != topLevelBlocks.end()) topLevelBlocks.erase(it); freeBlocks(draggedBlock);
                    } else {
                        DroppedBlock* bestTarget = nullptr; int minDistance = 99999; int snapType = 0; DroppedBlock* draggedTail = getBottomBlock(draggedBlock);
                        for (auto& root : topLevelBlocks) { if (root != draggedBlock) checkSnapping(root, draggedBlock, draggedTail, bestTarget, minDistance, snapType); }
                        if (bestTarget && snapType > 0) {
                            auto it = find(topLevelBlocks.begin(), topLevelBlocks.end(), draggedBlock); if (it != topLevelBlocks.end()) topLevelBlocks.erase(it);
                            if (snapType == 1) { bestTarget->next = draggedBlock; draggedBlock->parent = bestTarget; } else if (snapType == 2) { bestTarget->inside = draggedBlock; draggedBlock->parent = bestTarget; }
                            else if (snapType == 3) {
                                auto targetIt = find(topLevelBlocks.begin(), topLevelBlocks.end(), bestTarget); if (targetIt != topLevelBlocks.end()) topLevelBlocks.erase(targetIt);
                                DroppedBlock* tail = draggedBlock; while(tail->next) tail = tail->next; tail->next = bestTarget;
                                if (bestTarget->parent) {
                                    if (bestTarget->parent->next == bestTarget) bestTarget->parent->next = draggedBlock; else if (bestTarget->parent->inside == bestTarget) bestTarget->parent->inside = draggedBlock; else if (bestTarget->parent->inside2 == bestTarget) bestTarget->parent->inside2 = draggedBlock;
                                    draggedBlock->parent = bestTarget->parent;
                                } else { topLevelBlocks.push_back(draggedBlock); }
                                bestTarget->parent = tail;
                            }
                            else if (snapType == 4) { bestTarget->arg1 = draggedBlock; draggedBlock->parent = bestTarget; } else if (snapType == 5) { bestTarget->arg2 = draggedBlock; draggedBlock->parent = bestTarget; } else if (snapType == 6) { bestTarget->inside2 = draggedBlock; draggedBlock->parent = bestTarget; }
                            DroppedBlock* rootNode = draggedBlock->parent ? draggedBlock->parent : draggedBlock; while(rootNode && rootNode->parent) rootNode = rootNode->parent; updateBlockPositions(rootNode, rootNode->rect.x, rootNode->rect.y);
                        }
                    }
                    draggedBlock = nullptr;
                }
            }
        }

        SDL_RenderClear(renderer); SDL_RenderCopy(renderer, background, NULL, NULL);

        for (const auto& btn : catButtons) {
            if (btn.category == activeCategory) { SDL_SetRenderDrawColor(renderer, 150, 150, 150, 120); SDL_RenderFillRect(renderer, &btn.rect); }
            SDL_RenderCopy(renderer, btn.texture, NULL, &btn.rect);
        }

        SDL_Rect clipRect = {MENU_AREA_X, MENU_AREA_Y, MENU_AREA_W, MENU_AREA_H}; SDL_RenderSetClipRect(renderer, &clipRect);

        for (const auto& block : menuBlocks) {
            if (block.category != activeCategory) continue;
            SDL_Rect renderedRect = {block.rect.x, block.rect.y - scrollY, block.rect.w, block.rect.h};
            if (renderedRect.y + renderedRect.h < MENU_AREA_Y || renderedRect.y > MENU_AREA_Y + MENU_AREA_H) continue;

            SDL_RenderCopy(renderer, block.texture, NULL, &renderedRect);

            if (block.hasDropdown && !block.options.empty()) {
                int dx = renderedRect.x + block.dropdownRect.x; int dy = renderedRect.y + block.dropdownRect.y;
                SDL_Rect boxRect = {dx, dy, block.dropdownRect.w, block.dropdownRect.h};
                SDL_SetRenderDrawColor(renderer, 245, 245, 245, 255); SDL_RenderFillRect(renderer, &boxRect);
                SDL_SetRenderDrawColor(renderer, 80, 80, 80, 255); SDL_RenderDrawRect(renderer, &boxRect);
                SDL_Rect arrowRect = {dx + block.dropdownRect.w - 12, dy + 10, 6, 5};
                SDL_SetRenderDrawColor(renderer, 100, 100, 100, 255); SDL_RenderFillRect(renderer, &arrowRect);
                renderText(renderer, globalFont, block.options[block.selectedOptionIndex], dx + 5, dy + 2, colorBlack);
            }

            drawInputBoxes(renderer, renderedRect.x, renderedRect.y, block.inputFields);
            drawColorBoxes(renderer, renderedRect.x, renderedRect.y, block.colorFields);
        }

        SDL_Rect dropAreaRect = {DROP_AREA_X, DROP_AREA_Y, DROP_AREA_W, DROP_AREA_H}; SDL_RenderSetClipRect(renderer, &dropAreaRect);
        for (auto root : topLevelBlocks) { if (root != draggedBlock) renderBlockTree(renderer, root); }
        SDL_RenderSetClipRect(renderer, NULL);
        if (draggedBlock) { SDL_SetTextureAlphaMod(draggedBlock->texture, 180); renderBlockTree(renderer, draggedBlock); SDL_SetTextureAlphaMod(draggedBlock->texture, 255); }

        if (activeDropdownBlock || activeMenuDropdown) {
            int optH = 25; vector<string>* options = nullptr; int bx, by;
            if (activeDropdownBlock) { options = &activeDropdownBlock->options; bx = activeDropdownBlock->rect.x + activeDropdownBlock->dropdownRelativeRect.x; by = activeDropdownBlock->rect.y + activeDropdownBlock->dropdownRelativeRect.y + activeDropdownBlock->dropdownRelativeRect.h; }
            else { options = &activeMenuDropdown->options; int blockRenderY = activeMenuDropdown->rect.y - scrollY; bx = activeMenuDropdown->rect.x + activeMenuDropdown->dropdownRect.x; by = blockRenderY + activeMenuDropdown->dropdownRect.y + activeMenuDropdown->dropdownRect.h; }
            int w = 150; for(string s : *options) { if(s.length() > 10) w = 220; } int totalH = optH * options->size();
            SDL_Rect shadowRect = {bx + 4, by + 4, w, totalH}; SDL_SetRenderDrawColor(renderer, 0, 0, 0, 80); SDL_RenderFillRect(renderer, &shadowRect);
            SDL_Rect bgRect = {bx, by, w, totalH}; SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255); SDL_RenderFillRect(renderer, &bgRect); SDL_SetRenderDrawColor(renderer, 100, 100, 100, 255); SDL_RenderDrawRect(renderer, &bgRect);
            int mx, my; SDL_GetMouseState(&mx, &my);
            for (size_t i = 0; i < options->size(); ++i) {
                SDL_Rect optRect = {bx, by + (int)i * optH, w, optH};
                if (isMouseInside(mx, my, optRect)) { SDL_SetRenderDrawColor(renderer, 0, 120, 215, 255); SDL_RenderFillRect(renderer, &optRect); renderText(renderer, globalFont, (*options)[i], bx + 10, by + (int)i * optH + 3, colorWhite); }
                else { renderText(renderer, globalFont, (*options)[i], bx + 10, by + (int)i * optH + 3, colorBlack); }
            }
        }


        if (activeColorBox) {
            SDL_RenderSetClipRect(renderer, NULL);
            int palX = activeColorBoxAbsX; int palY = activeColorBoxAbsY + activeColorBox->h + 5;

            SDL_Rect bgRect = {palX - 4, palY - 4, 88, 88};
            SDL_SetRenderDrawColor(renderer, 240, 240, 240, 255);
            SDL_RenderFillRect(renderer, &bgRect);
            SDL_SetRenderDrawColor(renderer, 100, 100, 100, 255);
            SDL_RenderDrawRect(renderer, &bgRect);

            for (int i = 0; i < 9; i++) {
                int col = i % 3; int row = i / 3;
                SDL_Rect cRect = {palX + col * 28, palY + row * 28, 24, 24};
                SDL_SetRenderDrawColor(renderer, colorPalette[i].r, colorPalette[i].g, colorPalette[i].b, 255);
                SDL_RenderFillRect(renderer, &cRect);
                SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                SDL_RenderDrawRect(renderer, &cRect);
            }
        }


        if (activeTextBox) {
            SDL_RenderSetClipRect(renderer, NULL);
            SDL_Rect absBox = {activeTextBoxAbsX, activeTextBoxAbsY, activeTextBox->w, activeTextBox->h * 3};
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
            SDL_RenderFillRect(renderer, &absBox);
            SDL_SetRenderDrawColor(renderer, 0, 150, 255, 255);
            SDL_RenderDrawRect(renderer, &absBox);
            if (!activeTextBox->text.empty()) {
                renderText(renderer, globalFont, activeTextBox->text, absBox.x + 3, absBox.y + 1, colorBlack, absBox.w - 4);
            }
        }

        SDL_RenderPresent(renderer);
    }

    for(auto b : topLevelBlocks) freeBlocks(b);
    SDL_DestroyTexture(background); SDL_Quit(); return 0;
}

// ---------------------------------------------------------
void renderText(SDL_Renderer* renderer, TTF_Font* font, const string& text, int x, int y, SDL_Color color, int wrapW) {
    if (text.empty() || !font) return;
    SDL_Surface* surf = nullptr;
    if(wrapW > 0) surf = TTF_RenderUTF8_Blended_Wrapped(font, text.c_str(), color, wrapW);
    else surf = TTF_RenderUTF8_Blended(font, text.c_str(), color);
    if (!surf) return;
    SDL_Texture* tex = SDL_CreateTextureFromSurface(renderer, surf);
    SDL_Rect rect = {x, y, surf->w, surf->h};
    SDL_RenderCopy(renderer, tex, NULL, &rect);
    SDL_DestroyTexture(tex); SDL_FreeSurface(surf);
}

SDL_Texture* loadTex(const char* path, SDL_Renderer* renderer) {
    SDL_Surface* surf = IMG_Load(path); if (!surf) return nullptr;
    SDL_Texture* tex = SDL_CreateTextureFromSurface(renderer, surf); SDL_FreeSurface(surf); return tex;
}

bool isMouseInside(int mouseX, int mouseY, SDL_Rect rect) {
    return (mouseX >= rect.x && mouseX <= rect.x + rect.w && mouseY >= rect.y && mouseY <= rect.y + rect.h);
}

void assignInputs(MenuItem& block) {
    int h = 25; int y = 6;
    switch(block.type) {
        case BLOCK_MOTION_MOVE_STEPS: block.inputFields.push_back({50, y, 40, h, "10", false}); break;
        case BLOCK_MOTION_TURN_RIGHT:
        case BLOCK_MOTION_TURN_LEFT: block.inputFields.push_back({78, y, 40, h, "15", false}); break;
        case BLOCK_MOTION_GO_TO_XY:
            block.inputFields.push_back({68, y, 40, h, "0", false});
            block.inputFields.push_back({129, y, 38, h, "0", false}); break;
        case BLOCK_MOTION_POINT_DIRECTION: block.inputFields.push_back({127, y, 35, h, "90", false}); break;
        case BLOCK_MOTION_CHANGR_X:
        case BLOCK_MOTION_CHANGE_Y: block.inputFields.push_back({77, y, 55, h, "10", false}); break;

        case BLOCK_LOOKS_SAY_FOR_TIME:
            block.inputFields.push_back({37, y, 60, h, "Hello!", false});
            block.inputFields.push_back({125, y, 35, h, "2", false}); break;
        case BLOCK_LOOKS_SAY: block.inputFields.push_back({35, y, 61, h, "Hello!", false}); break;
        case BLOCK_LOOKS_THINK_FOR_TIME:
            block.inputFields.push_back({50, y, 58, h, "Hmm...", false});
            block.inputFields.push_back({137, y, 32, h, "2", false}); break;
        case BLOCK_LOOKS_THINK: block.inputFields.push_back({47, y, 60, h, "Hmm...", false}); break;
        case BLOCK_LOOKS_CHANGE_SIZE: block.inputFields.push_back({110, y, 35, h, "10", false}); break;
        case BLOCK_LOOKS_SET_SIZE: block.inputFields.push_back({80, y, 38, h, "100", false}); break;
        case BLOCK_LOOKS_CHANGE_EFFECT: block.inputFields.push_back({218, y, 43, h, "25", false}); break;
        case BLOCK_LOOKS_SET_EFFECT: block.inputFields.push_back({186, y, 43, h, "0", false}); break;

        case BLOCK_SOUND_CHANGE_VOLUME: block.inputFields.push_back({190, y, 35, h, "10", false}); break;
        case BLOCK_SOUND_SET_VOLUME: block.inputFields.push_back({160, y, 35, h, "100", false}); break;

        case BLOCK_CONTROL_WAIT: block.inputFields.push_back({45, y, 35, h, "1", false}); break;
        case BLOCK_CONTROL_REPEAT: block.inputFields.push_back({80, y, 35, h, "10", false}); break;

        case BLOCK_SENSING_ASK_AND_WAIT: block.inputFields.push_back({36, y, 133, h, "What's your name?", false}); break;

        case BLOCK_SENSING_TOUCHING_COLOR:
            block.colorFields.push_back({ 132, 6, 45, 25, {0, 255, 0, 255}, false });
            break;
        case BLOCK_SENSING_COLOR_TOUCHING:
            block.colorFields.push_back({ 68, 5, 35, 25, {0, 255, 0, 255}, false });
            block.colorFields.push_back({ 193, 5, 32, 25, {10, 120, 100, 255}, false });
            break;

        case BLOCK_OPERATOR_ADD:
        case BLOCK_OPERATOR_SUBTRACT:
        case BLOCK_OPERATOR_MULTIPLY:
        case BLOCK_OPERATOR_DIVIDE:
            block.inputFields.push_back({7, y, 33, h, "", false});
            block.inputFields.push_back({53, y, 33, h, "", false}); break;
        case BLOCK_OPERATOR_GREATER_THAN:
        case BLOCK_OPERATOR_LESS_THAN:
        case BLOCK_OPERATOR_EQUAL:
            block.inputFields.push_back({13, y, 30, h, "", false});
            block.inputFields.push_back({65, y, 30, h, "", false}); break;
        case BLOCK_OPERATOR_JOIN_STRING:
            block.inputFields.push_back({45, y, 55, h, "banana", false});
            block.inputFields.push_back({105, y, 51, h, "apple", false}); break;
        case BLOCK_OPERATOR_LETTER_OF:
            block.inputFields.push_back({55, y, 35, h, "1", false});
            block.inputFields.push_back({113, y, 47, h, "apple", false}); break;
        case BLOCK_OPERATOR_LENGTH_OF:
            block.inputFields.push_back({90, y, 59, h, "apple", false}); break;
        default: break;
    }
}

void setupMenu(SDL_Renderer* renderer, vector<CategoryButton>& catButtons, vector<MenuItem>& allBlocks) {
    int btnX = 16, btnY = 160, btnW = 55, btnGap = 85;
    auto addCategory = [&](BlockCategory cat, const char* path, int index) {
        SDL_Texture* tex = loadTex(path, renderer); if (!tex) return; int originalW, originalH; SDL_QueryTexture(tex, NULL, NULL, &originalW, &originalH);
        int btnH = (originalH * btnW) / originalW; catButtons.push_back({cat, tex, {btnX, btnY + (index * btnGap), btnW, btnH}, false});
    };

    addCategory(CAT_MOTION,   "Motion_tab.png",    0); addCategory(CAT_LOOKS,    "looks_tab.png",      1);
    addCategory(CAT_SOUND,    "sound_tab.png",      2); addCategory(CAT_EVENTS,   "events_tab.png",     3);
    addCategory(CAT_CONTROL,  "control_tab.png",    4); addCategory(CAT_SENSING,  "sensing_tab.png",    5);
    btnX = 8; btnW = 70; addCategory(CAT_OPERATORS,"operators_tab.png",  6);

    int startX = 120, startY = 160, currentY = startY; int blockGap = 15; float blockScale = 0.23f;
    auto addBlock = [&](BlockType type, BlockCategory cat, const char* path) {
        SDL_Texture* tex = loadTex(path, renderer); if (!tex) return; int origW, origH; SDL_QueryTexture(tex, NULL, NULL, &origW, &origH);
        int destW = (int)(origW * blockScale); int destH = (int)(origH * blockScale); SDL_Rect emptyDropRect = {0,0,0,0};
        allBlocks.push_back({type, cat, tex, {startX, currentY, destW, destH}, false, false, emptyDropRect, false, vector<string>(), 0, {}, {}});
        assignInputs(allBlocks.back());
        currentY += destH + blockGap;
    };

    // MOTION
    addBlock(BLOCK_MOTION_MOVE_STEPS, CAT_MOTION, "Motion_1.png"); addBlock(BLOCK_MOTION_TURN_RIGHT, CAT_MOTION, "Motion_2.png"); addBlock(BLOCK_MOTION_TURN_LEFT,  CAT_MOTION, "Motion_3.png"); currentY += 20;
    {
        SDL_Texture* t = loadTex("Motion_8.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_MOTION_GO_TO, CAT_MOTION, t, {startX,currentY,dw,dh}, false, true, {50,5,135,25}, false, {"random position","mouse-pointer"}, 0, {}, {}});
            assignInputs(allBlocks.back());
            currentY += dh + blockGap;
        }
    }
    addBlock(BLOCK_MOTION_GO_TO_XY, CAT_MOTION, "Motion_4.png"); currentY += 20; addBlock(BLOCK_MOTION_POINT_DIRECTION,CAT_MOTION, "Motion_7.png"); currentY += 20; addBlock(BLOCK_MOTION_CHANGR_X, CAT_MOTION, "Motion_5.png"); addBlock(BLOCK_MOTION_CHANGE_Y, CAT_MOTION, "Motion_6.png");

    // LOOKS
    currentY = startY;
    addBlock(BLOCK_LOOKS_SAY_FOR_TIME,  CAT_LOOKS, "Looks_3.png"); addBlock(BLOCK_LOOKS_SAY,           CAT_LOOKS, "Looks_1.png"); addBlock(BLOCK_LOOKS_THINK_FOR_TIME,CAT_LOOKS, "Looks_4.png"); addBlock(BLOCK_LOOKS_THINK,         CAT_LOOKS, "Looks_2.png"); currentY += 20;
    {
        SDL_Texture* t = loadTex("Looks_5.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_LOOKS_SWITCH_COSTUME, CAT_LOOKS, t, {startX,currentY,dw,dh}, false, true, {115,6,108,25}, false, {"costume1","costume2","next costume"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    addBlock(BLOCK_LOOKS_NEXT_COSTUME, CAT_LOOKS, "Looks_6.png");
    {
        SDL_Texture* t = loadTex("Looks_7.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_LOOKS_SWITCH_BACKDROP, CAT_LOOKS, t, {startX,currentY,dw,dh}, false, true, {120,6,111,25}, false, {"backdrop1","next backdrop","previous backdrop","random backdrop"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    addBlock(BLOCK_LOOKS_NEXT_BACKDROP, CAT_LOOKS, "Looks_8.png"); currentY += 20; addBlock(BLOCK_LOOKS_CHANGE_SIZE, CAT_LOOKS, "Looks_9.png"); addBlock(BLOCK_LOOKS_SET_SIZE,    CAT_LOOKS, "Looks_10.png"); currentY += 20;
    {
        SDL_Texture* t = loadTex("Looks_11.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_LOOKS_CHANGE_EFFECT, CAT_LOOKS, t, {startX,currentY,dw,dh}, false, true, {65,6,85,25}, false, {"color","fisheye","whirl","pixelate","mosaic","brightness","ghost"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    {
        SDL_Texture* t = loadTex("Looks_12.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_LOOKS_SET_EFFECT, CAT_LOOKS, t, {startX,currentY,dw,dh}, false, true, {35,6,82,25}, false, {"color","fisheye","whirl","pixelate","mosaic","brightness","ghost"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    addBlock(BLOCK_LOOKS_CLEAR_EFFECTS, CAT_LOOKS, "Looks_13.png"); currentY += 20; addBlock(BLOCK_LOOKS_SHOW, CAT_LOOKS, "Looks_14.png"); addBlock(BLOCK_LOOKS_HIDE, CAT_LOOKS, "Looks_15.png"); currentY += 20;
    {
        SDL_Texture* t = loadTex("Looks_16.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_LOOKS_GO_TO_FRONT_BACK, CAT_LOOKS, t, {startX,currentY,dw,dh}, false, true, {52,6,53,25}, false, {"front","back"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    {
        SDL_Texture* t = loadTex("Looks_17.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_LOOKS_GO_FORWARD_BACKWARD, CAT_LOOKS, t, {startX,currentY,dw,dh}, false, true, {32,6,110,25}, false, {"forward","backward"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    {
        SDL_Texture* t = loadTex("Looks_18.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_LOOKS_COSTUME_NUMBER_NAME, CAT_LOOKS, t, {startX,currentY,dw,dh}, false, true, {68,6,75,25}, false, {"number","name"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    {
        SDL_Texture* t = loadTex("Looks_19.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_LOOKS_BACKDROP_NUMBER_NAME, CAT_LOOKS, t, {startX,currentY,dw,dh}, false, true, {75,6,74,25}, false, {"number","name"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    addBlock(BLOCK_LOOKS_SIZE, CAT_LOOKS, "Looks_20.png");

    // SOUND
    currentY = startY;
    {
        SDL_Texture* t = loadTex("Suonds_1.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_SOUND_PLAY_UNTIL_DONE, CAT_SOUND, t, {startX,currentY,dw,dh}, false, true, {86,6,78,25}, false, {"Meow","record..."}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    {
        SDL_Texture* t = loadTex("Suonds_2.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_SOUND_PLAY, CAT_SOUND, t, {startX,currentY,dw,dh}, false, true, {86,6,78,25}, false, {"Meow","record..."}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    addBlock(BLOCK_SOUND_STOP_ALL, CAT_SOUND, "Suonds_3.png"); currentY += 20;
    {
        SDL_Texture* t = loadTex("Suonds_4.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_SOUND_CHANGE_VOLUME, CAT_SOUND, t, {startX,currentY,dw,dh}, false, true, {60,6,67,25}, false, {"pitch","pan left/right"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    {
        SDL_Texture* t = loadTex("Suonds_5.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_SOUND_SET_VOLUME, CAT_SOUND, t, {startX,currentY,dw,dh}, false, true, {31,6,67,25}, false, {"pitch","pan left/right"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    addBlock(BLOCK_SOUND_CLEAR_EFFECTS, CAT_SOUND, "Suonds_6.png");

    // EVENTS
    currentY = startY;
    addBlock(BLOCK_EVENT_FLAG_CLICKED, CAT_EVENTS, "Events_1.png");
    {
        SDL_Texture* t = loadTex("Events_2.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_EVENT_KEY_PRESSED, CAT_EVENTS, t, {startX,currentY,dw,dh}, false, true, {55,6,95,25}, false, {"space","up arrow","down arrow","right arrow","left arrow","any","a"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    currentY += 20;
    {
        SDL_Texture* t = loadTex("Events_4.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_EVENT_WHEN_RECIEVE, CAT_EVENTS, t, {startX,currentY,dw,dh}, false, true, {115,6,120,25}, false, {"message1","new message..."}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    {
        SDL_Texture* t = loadTex("Events_3.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_EVENT_BROADCAST, CAT_EVENTS, t, {startX,currentY,dw,dh}, false, true, {80,6,128,25}, false, {"message1","new message..."}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }

    // CONTROL
    currentY = startY;
    addBlock(BLOCK_CONTROL_WAIT,       CAT_CONTROL, "Control_1.png"); currentY += 20; addBlock(BLOCK_CONTROL_REPEAT,     CAT_CONTROL, "Control_2.png"); addBlock(BLOCK_CONTROL_FOREVER,    CAT_CONTROL, "Control_3.png"); currentY += 20; addBlock(BLOCK_CONTROL_IF,         CAT_CONTROL, "Control_4.png"); addBlock(BLOCK_CONTROL_IF_ELSE,    CAT_CONTROL, "Control_5.png"); addBlock(BLOCK_CONTROL_WAIT_UNTIL, CAT_CONTROL, "Control_6.png"); addBlock(REPEAT_UNTIL,             CAT_CONTROL, "Control_8.png"); addBlock(BLOCK_CONTROL_STOP_ALL,   CAT_CONTROL, "Control_7.png");

    // SENSING
    currentY = startY;
    {
        SDL_Texture* t = loadTex("Sensing_2.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_SENSING_TOUCHING_OBJECT, CAT_SENSING, t, {startX,currentY,dw,dh}, false, true, {88,6,115,25}, false, {"mouse-pointer","edge"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    addBlock(BLOCK_SENSING_TOUCHING_COLOR, CAT_SENSING, "Sensing_3.png"); addBlock(BLOCK_SENSING_COLOR_TOUCHING, CAT_SENSING, "Sensing_1.png");
    {
        SDL_Texture* t = loadTex("Sensing_4.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_SENSING_DISTANCE_TO, CAT_SENSING, t, {startX,currentY,dw,dh}, false, true, {87,6,116,25}, false, {"mouse-pointer"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    currentY += 20; addBlock(BLOCK_SENSING_ASK_AND_WAIT, CAT_SENSING, "Sensing_5.png"); addBlock(BLOCK_SENSING_ANSWER,       CAT_SENSING, "Sensing_6.png");
    {
        SDL_Texture* t = loadTex("Sensing_7.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_SENSING_KEY_PRESSED, CAT_SENSING, t, {startX,currentY,dw,dh}, false, true, {65,6,99,25}, false, {"space","up arrow","down arrow","right arrow","left arrow","any","a"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    currentY += 20; addBlock(BLOCK_SENSING_MOUSE_DOWN, CAT_SENSING, "Sensing_8.png"); addBlock(BLOCK_SENSING_MOUSE_X,    CAT_SENSING, "Sensing_9.png"); addBlock(BLOCK_SENSING_MOUSE_Y,    CAT_SENSING, "Sensing_10.png");
    {
        SDL_Texture* t = loadTex("Sensing_11.png", renderer);
        if (t) {
            int w,h; SDL_QueryTexture(t,NULL,NULL,&w,&h); int dw=(int)(w*blockScale), dh=(int)(h*blockScale);
            allBlocks.push_back({BLOCK_SENSING_SET_DRAG_MODE, CAT_SENSING, t, {startX,currentY,dw,dh}, false, true, {112,6,95,25}, false, {"draggable","not draggable"}, 0, {}, {}});
            assignInputs(allBlocks.back()); currentY += dh + blockGap;
        }
    }
    currentY += 20; addBlock(BLOCK_SENSING_TIMER,       CAT_SENSING, "Sensing_12.png"); addBlock(BLOCK_SENSING_RESET_TIMER, CAT_SENSING, "Sensing_13.png");

    // OPERATORS
    currentY = startY;
    addBlock(BLOCK_OPERATOR_ADD,      CAT_OPERATORS, "Operators_plus.png");
    addBlock(BLOCK_OPERATOR_SUBTRACT, CAT_OPERATORS, "Operators_minus.png");
    addBlock(BLOCK_OPERATOR_MULTIPLY, CAT_OPERATORS, "Operators_multiply.png");
    addBlock(BLOCK_OPERATOR_DIVIDE,   CAT_OPERATORS, "Operators_devision.png");
    currentY += 20;
    addBlock(BLOCK_OPERATOR_GREATER_THAN, CAT_OPERATORS, "Operators_greater than.png");
    addBlock(BLOCK_OPERATOR_LESS_THAN,    CAT_OPERATORS, "Operators_less than.png");
    addBlock(BLOCK_OPERATOR_EQUAL,        CAT_OPERATORS, "Operators_equals.png");
    currentY += 20;
    addBlock(BLOCK_OPERATOR_AND, CAT_OPERATORS, "Operators_and.png");
    addBlock(BLOCK_OPERATOR_OR,  CAT_OPERATORS, "Operators_or.png");
    addBlock(BLOCK_OPERATOR_NOT, CAT_OPERATORS, "Operators_not.png");
    currentY += 20;
    addBlock(BLOCK_OPERATOR_JOIN_STRING,  CAT_OPERATORS, "Operators_joinToString.png");
    addBlock(BLOCK_OPERATOR_LETTER_OF,    CAT_OPERATORS, "Operators_LetterOfString.png");
    addBlock(BLOCK_OPERATOR_LENGTH_OF,    CAT_OPERATORS, "Operators_LengthOfString.png");
}